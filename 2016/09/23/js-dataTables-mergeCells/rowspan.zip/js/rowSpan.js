$(document).ready(function () {
    var table = $('#example').dataTable({
        "lengthChange": false, // 禁止选择每页显示条数
        "ordering": false, // 禁止排序
        "searching": false, // 禁止搜索
        "columnDefs": [
            {"visible": true, "targets": 0}
        ],
        "displayLength": 25,
        "drawCallback": function (settings) {
            console.log('drawCallback test');
            var api = this.api();
            var rows = api.rows({page: 'current'}).nodes();

            console.log('idx = ' + rows[0].cells.length);

            // 后面的列先进行合并
            for (var idx = rows[0].cells.length - 1; idx >= 0; idx--) {
                var last = null;
                var tr = null;
                var ltd = null;
                api.column(idx, {page: 'current'}).data().each(function (group, i) {
                    tr = $(rows[i]);
                    var td = $("td:eq(" + idx + ")", tr);
                    if (last !== group) {
                        td.attr("rowspan", 1);
                        td.text(group);
                        ltd = td;
                        last = group;
                    } else {
                        ltd.attr("rowspan", parseInt(ltd.attr("rowspan")) + 1);
                        td.remove();
                    }
                });
            }
        }
    });
});
